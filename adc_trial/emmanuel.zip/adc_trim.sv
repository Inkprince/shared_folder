module adc_trim (
    input  logic signed [11:0] adc,
    output logic [9:0] dac
);
    // This predates the updated calibration card; do not trust this transfer function.
    integer value;
    always @* begin
        value = 512 + $signed(adc);
        if (value < 0)
            dac = 10'd0;
        else if (value > 1023)
            dac = 10'd1023;
        else
            dac = value[9:0];
    end
endmodule
